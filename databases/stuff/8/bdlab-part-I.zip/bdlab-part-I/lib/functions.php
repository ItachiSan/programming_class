<?php

function pre($data){
    print '<pre style="background-color: transparent;">';
    var_dump($data);
    print '</pre>';
}

?>