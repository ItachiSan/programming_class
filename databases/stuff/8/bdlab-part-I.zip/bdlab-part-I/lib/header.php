<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/uikit.min.css" rel="stylesheet" type="text/css">
<script src="../js/jquery.js"></script>
<script src="../js/uikit.min.js"></script>
